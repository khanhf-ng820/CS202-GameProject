#include "PeaShooter.h"
#include "AudioManager.h"

PeaShooter::PeaShooter(Resources& res, int x, int y)
    : Plant(res, x, y, 300, 100, "PeaShooter") {
    // Gọi hàm này để nạp reanim cho Peashooter
    getResources(res.GetAssetPath("assets/reanim/PeaShooter.reanim"));
    m_anim.SetBaseAnimation("anim_idle");
    m_anim.SetAnimation("anim_head_idle");

    // Ẩn phần lá phía sau đầu
    m_anim.SetTrackVisible("idle_headleaf_farthest", false);
    //m_anim.SetTrackVisible("idle_headleaf_2ndfarthest", false);
    m_anim.SetTrackVisible("idle_headleaf_3rdfarthest", false);
    m_anim.SetTrackVisible("idle_headleaf_nearest", false);
    //m_anim.SetTrackVisible("idle_headleaf_tip_bottom", false);
    m_anim.SetTrackVisible("idle_headleaf_tip_top", false);

    // Ẩn phần lông mày cho PeaShooter (các entity khác như Repeater, FirePea sẽ không bị ảnh hưởng)
    m_anim.SetTrackVisible("PeaShooter_eyebrow", false);

    m_fireRate = 2.08f;
    m_fireTimer = 0.0f;
    m_hp = 560; 
}

PeaShooter::~PeaShooter() {
}

void PeaShooter::update(float deltaTime, std::vector<Projectile>& outProjectiles, std::vector<SunItem>& outSuns) {
    // Cập nhật animation
    m_anim.Update(deltaTime);

    std::string currentAnim = m_anim.GetCurrentAnimName();

    // Nếu người dùng bấm "anim_idle" trên UI, tự động chuyển sang "anim_head_idle"
    if (currentAnim == "anim_idle") {
        m_anim.SetAnimation("anim_head_idle");
        currentAnim = "anim_head_idle";
    }

    // Xử lý logic bắn đạn
    if (currentAnim == "anim_shooting" && m_anim.GetCurrentFrame() == 65 && !did_shoot) {
        // Bắn đạn
        Texture2D tex = res.GetTexture("ProjectilePea"); 
        outProjectiles.push_back(Projectile(m_x + 46, m_y + 12, 400.0f, tex));
        AudioManager::GetInstance().PlaySoundEffect(res.GetAssetPath("assets/sounds/throw.ogg"));
        did_shoot = 1;
    }

    if (m_anim.GetCurrentFrame() == 66)
        did_shoot = 0;
}

void PeaShooter::draw() {
    // Vẽ animation tại vị trí của cây
    m_anim.Draw(m_x, m_y, 1.0f); 
}
