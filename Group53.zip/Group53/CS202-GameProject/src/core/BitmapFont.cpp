#include "BitmapFont.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <vector>
#include <algorithm>
#include <cctype>
#include <cstring>
#include <cmath>

// ---------------------------------------------------------------------------
// Helper: trim whitespace from both ends
// ---------------------------------------------------------------------------
static std::string Trim(const std::string& s) {
    size_t start = s.find_first_not_of(" \t\r\n");
    if (start == std::string::npos) return "";
    size_t end = s.find_last_not_of(" \t\r\n");
    return s.substr(start, end - start + 1);
}

// ---------------------------------------------------------------------------
// Helper: parse a parenthesised list of chars, e.g. ('A', 'B', ...)
// Returns only basic ASCII chars (skips multi-byte / invalid entries).
// ---------------------------------------------------------------------------
static std::vector<char> ParseCharList(const std::string& body) {
    std::vector<char> result;
    size_t openParen = body.find('(');
    size_t closeParen = body.rfind(')');
    if (openParen == std::string::npos || closeParen == std::string::npos || closeParen <= openParen) {
        return result;
    }

    std::string content = body.substr(openParen + 1, closeParen - openParen - 1);
    size_t i = 0;
    while (i < content.size()) {
        // Skip whitespace and delimiter commas between character tokens
        while (i < content.size() && (content[i] == ' ' || content[i] == '\t' || content[i] == '\r' || content[i] == '\n' || content[i] == ',')) {
            i++;
        }
        if (i >= content.size()) break;

        char quote = content[i];
        if (quote == '\'' || quote == '"') {
            i++;
            size_t endQuote = content.find(quote, i);
            if (endQuote != std::string::npos) {
                std::string inside = content.substr(i, endQuote - i);
                if (inside.size() == 1 && static_cast<unsigned char>(inside[0]) < 128) {
                    result.push_back(inside[0]);
                } else {
                    result.push_back('\0');
                }
                i = endQuote + 1;
            } else {
                break;
            }
        } else {
            i++;
        }
    }

    return result;
}

// ---------------------------------------------------------------------------
// Helper: parse a parenthesised list of ints, e.g. ( 22, 18, 19, ... )
// ---------------------------------------------------------------------------
static std::vector<int> ParseIntList(const std::string& body) {
    std::vector<int> result;
    std::string clean;
    for (char c : body) {
        if (c == '(' || c == ')') continue;
        clean += c;
    }
    std::istringstream iss(clean);
    std::string token;
    while (std::getline(iss, token, ',')) {
        token = Trim(token);
        if (!token.empty()) {
            try {
                result.push_back(std::stoi(token));
            } catch (...) {
                result.push_back(0);
            }
        }
    }
    return result;
}

// ---------------------------------------------------------------------------
// Helper: parse a list of (x, y, w, h) tuples
// ---------------------------------------------------------------------------
static std::vector<Rectangle> ParseRectList(const std::string& body) {
    std::vector<Rectangle> result;
    size_t pos = 0;
    while (pos < body.size()) {
        size_t open = body.find('(', pos);
        if (open == std::string::npos) break;
        size_t close = body.find(')', open);
        if (close == std::string::npos) break;

        std::string inner = body.substr(open + 1, close - open - 1);
        std::vector<int> vals = ParseIntList("(" + inner + ")");
        if (vals.size() >= 4) {
            result.push_back({(float)vals[0], (float)vals[1], (float)vals[2], (float)vals[3]});
        }
        pos = close + 1;
    }
    return result;
}

// ---------------------------------------------------------------------------
// Helper: parse a list of (x, y) offset tuples
// ---------------------------------------------------------------------------
static std::vector<Vector2> ParseOffsetList(const std::string& body) {
    std::vector<Vector2> result;
    size_t pos = 0;
    while (pos < body.size()) {
        size_t open = body.find('(', pos);
        if (open == std::string::npos) break;
        size_t close = body.find(')', open);
        if (close == std::string::npos) break;

        std::string inner = body.substr(open + 1, close - open - 1);
        std::vector<int> vals = ParseIntList("(" + inner + ")");
        if (vals.size() >= 2) {
            result.push_back({(float)vals[0], (float)vals[1]});
        }
        pos = close + 1;
    }
    return result;
}

// ---------------------------------------------------------------------------
// Helper: parse kerning pair strings, e.g. ("AV","AW", ...)
// ---------------------------------------------------------------------------
static std::vector<std::string> ParseStringList(const std::string& body) {
    std::vector<std::string> result;
    size_t pos = 0;
    while (pos < body.size()) {
        size_t q1 = body.find('"', pos);
        if (q1 == std::string::npos) break;
        size_t q2 = body.find('"', q1 + 1);
        if (q2 == std::string::npos) break;
        result.push_back(body.substr(q1 + 1, q2 - q1 - 1));
        pos = q2 + 1;
    }
    return result;
}

// ---------------------------------------------------------------------------
// Helper: read the entire body following a "Define <Name>" block.
// The body spans from the next line after "Define <Name>" until the next
// "Define" or non-continuation line.
// ---------------------------------------------------------------------------
static std::string ReadDefineBody(std::ifstream& file) {
    std::string body;
    std::string line;
    std::streampos prevPos = file.tellg();
    while (std::getline(file, line)) {
        std::string trimmed = Trim(line);
        if (trimmed.empty()) {
            prevPos = file.tellg();
            continue;
        }
        // If the line starts with a new command keyword, we've gone too far
        if (trimmed.rfind("Define", 0) == 0 ||
            trimmed.rfind("CreateLayer", 0) == 0 ||
            trimmed.rfind("LayerSet", 0) == 0 ||
            trimmed.rfind("SetDefault", 0) == 0) {
            file.seekg(prevPos);
            break;
        }
        body += " " + trimmed;
        prevPos = file.tellg();
    }
    return body;
}

// ---------------------------------------------------------------------------
// BitmapFont::Load
// ---------------------------------------------------------------------------
bool BitmapFont::Load(const std::string& pngPath, const std::string& txtPath) {
    // Load the atlas image
    Image img = LoadImage(pngPath.c_str());
    if (img.data == nullptr) {
        // Fallback check for PopCap font atlas files with a leading underscore (e.g. _BrianneTod16.png)
        size_t lastSlash = pngPath.find_last_of("/\\");
        std::string altPath = (lastSlash == std::string::npos)
            ? "_" + pngPath
            : pngPath.substr(0, lastSlash + 1) + "_" + pngPath.substr(lastSlash + 1);
        img = LoadImage(altPath.c_str());
    }

    if (img.data == nullptr) {
        std::cerr << "BitmapFont: Failed to load atlas image: " << pngPath << std::endl;
        return false;
    }

    // Ensure RGBA 32-bit format
    ImageFormat(&img, PIXELFORMAT_UNCOMPRESSED_R8G8B8A8);
    Color* pixels = (Color*)img.data;
    int pixelCount = img.width * img.height;

    // Check if the image already has transparent pixels
    bool hasExistingAlpha = false;
    for (int i = 0; i < pixelCount; ++i) {
        if (pixels[i].a < 255) {
            hasExistingAlpha = true;
            break;
        }
    }

    // If image has no alpha transparency channel (like PopCap _*.png fonts),
    // convert pixel RGB luminance/brightness into the alpha channel.
    if (!hasExistingAlpha) {
        for (int i = 0; i < pixelCount; ++i) {
            unsigned char alpha = std::max({ pixels[i].r, pixels[i].g, pixels[i].b });
            pixels[i] = Color{ 255, 255, 255, alpha };
        }
    }

    m_atlas = LoadTextureFromImage(img);
    UnloadImage(img);

    if (m_atlas.id == 0) {
        std::cerr << "BitmapFont: Failed to create atlas texture: " << pngPath << std::endl;
        return false;
    }

    // Parse the descriptor file
    std::ifstream file(txtPath);
    if (!file.is_open()) {
        std::cerr << "BitmapFont: Failed to open descriptor: " << txtPath << std::endl;
        return false;
    }

    m_glyphHeight = 0;

    std::vector<char> charList;
    std::vector<int> widthList;
    std::vector<Rectangle> rectList;
    std::vector<Vector2> offsetList;
    std::vector<std::string> kerningPairs;
    std::vector<int> kerningValues;

    std::string line;
    while (std::getline(file, line)) {
        std::string trimmed = Trim(line);
        if (trimmed.empty()) continue;

        if (trimmed.rfind("Define CharList", 0) == 0) {
            std::string body = ReadDefineBody(file);
            charList = ParseCharList(body);
        }
        else if (trimmed.rfind("Define WidthList", 0) == 0) {
            std::string body = ReadDefineBody(file);
            widthList = ParseIntList(body);
        }
        else if (trimmed.rfind("Define RectList", 0) == 0) {
            std::string body = ReadDefineBody(file);
            rectList = ParseRectList(body);
        }
        else if (trimmed.rfind("Define OffsetList", 0) == 0) {
            std::string body = ReadDefineBody(file);
            offsetList = ParseOffsetList(body);
        }
        else if (trimmed.rfind("Define KerningPairs", 0) == 0) {
            std::string body = ReadDefineBody(file);
            kerningPairs = ParseStringList(body);
        }
        else if (trimmed.rfind("Define KerningValues", 0) == 0) {
            std::string body = ReadDefineBody(file);
            kerningValues = ParseIntList(body);
        }
    }

    // Build the glyph map (ASCII only — skip null placeholders)
    size_t count = std::min({charList.size(), widthList.size(), rectList.size(), offsetList.size()});
    for (size_t i = 0; i < count; ++i) {
        char ch = charList[i];
        if (ch == '\0') continue;  // Skip non-ASCII placeholders
        GlyphInfo glyph;
        glyph.srcRect = rectList[i];
        glyph.advanceWidth = widthList[i];
        glyph.offset = offsetList[i];
        m_glyphs[ch] = glyph;

        // Track native glyph height from first valid rect
        if (m_glyphHeight == 0 && glyph.srcRect.height > 0) {
            m_glyphHeight = (int)glyph.srcRect.height;
        }
    }

    // Also add space if not already present
    if (m_glyphs.find(' ') == m_glyphs.end()) {
        GlyphInfo space;
        space.srcRect = {0, 0, 0, 0};
        space.advanceWidth = 14;  // From the descriptor: LayerSetCharWidths Main (' ') (14)
        space.offset = {0, 0};
        m_glyphs[' '] = space;
    }

    // Build the kerning map
    size_t kernCount = std::min(kerningPairs.size(), kerningValues.size());
    for (size_t i = 0; i < kernCount; ++i) {
        if (kerningPairs[i].length() >= 2) {
            uint16_t key = ((uint16_t)(uint8_t)kerningPairs[i][0] << 8) | (uint16_t)(uint8_t)kerningPairs[i][1];
            m_kerning[key] = kerningValues[i];
        }
    }

    std::cout << "BitmapFont: Loaded " << m_glyphs.size() << " glyphs, "
              << m_kerning.size() << " kerning pairs" << std::endl;

    return true;
}

// ---------------------------------------------------------------------------
// BitmapFont::Unload
// ---------------------------------------------------------------------------
void BitmapFont::Unload() {
    if (m_atlas.id != 0) {
        UnloadTexture(m_atlas);
        m_atlas = {0};
    }
    m_glyphs.clear();
    m_kerning.clear();
}

// ---------------------------------------------------------------------------
// BitmapFont::MeasureText
// ---------------------------------------------------------------------------
int BitmapFont::MeasureText(const char* text, float scale) const {
    if (!text) return 0;

    float totalWidth = 0.0f;
    size_t len = std::strlen(text);

    for (size_t i = 0; i < len; ++i) {
        char ch = text[i];
        auto it = m_glyphs.find(ch);
        if (it == m_glyphs.end()) continue;

        totalWidth += (float)it->second.advanceWidth;

        // Apply kerning if there's a next character
        if (i + 1 < len) {
            uint16_t key = ((uint16_t)(uint8_t)ch << 8) | (uint16_t)(uint8_t)text[i + 1];
            auto kit = m_kerning.find(key);
            if (kit != m_kerning.end()) {
                totalWidth += (float)kit->second;
            }
        }
    }

    return (int)(totalWidth * scale);
}

// ---------------------------------------------------------------------------
// BitmapFont::DrawText
// ---------------------------------------------------------------------------
void BitmapFont::DrawText(const char* text, float x, float y, float scale, Color tint) const {
    if (!text || m_atlas.id == 0) return;

    float cursorX = x;
    size_t len = std::strlen(text);

    for (size_t i = 0; i < len; ++i) {
        char ch = text[i];
        auto it = m_glyphs.find(ch);
        if (it == m_glyphs.end()) continue;

        const GlyphInfo& glyph = it->second;

        // Only draw if the glyph has a valid source rect (space has zero-size rect)
        if (glyph.srcRect.width > 0 && glyph.srcRect.height > 0) {
            Rectangle dest = {
                cursorX + glyph.offset.x * scale,
                y + glyph.offset.y * scale,
                glyph.srcRect.width * scale,
                glyph.srcRect.height * scale
            };
            DrawTexturePro(m_atlas, glyph.srcRect, dest, {0, 0}, 0.0f, tint);
        }

        cursorX += (float)glyph.advanceWidth * scale;

        // Apply kerning
        if (i + 1 < len) {
            uint16_t key = ((uint16_t)(uint8_t)ch << 8) | (uint16_t)(uint8_t)text[i + 1];
            auto kit = m_kerning.find(key);
            if (kit != m_kerning.end()) {
                cursorX += (float)kit->second * scale;
            }
        }
    }
}

// ---------------------------------------------------------------------------
// BitmapFont::DrawTextCentered
// ---------------------------------------------------------------------------
void BitmapFont::DrawTextCentered(const char* text, Rectangle bounds, float scale, Color tint) const {
    int textW = MeasureText(text, scale);
    float textH = (float)m_glyphHeight * scale;

    float x = bounds.x + (bounds.width - (float)textW) / 2.0f;
    float y = bounds.y + (bounds.height - textH) / 2.0f;

    DrawText(text, x, y, scale, tint);
}

// ---------------------------------------------------------------------------
// BitmapFont::DrawTextRightAligned
// ---------------------------------------------------------------------------
void BitmapFont::DrawTextRightAligned(const char* text, Rectangle bounds, float paddingRight, float scale, Color tint) const {
    int textW = MeasureText(text, scale);
    float textH = (float)m_glyphHeight * scale;

    float x = bounds.x + bounds.width - paddingRight - (float)textW;
    float y = bounds.y + (bounds.height - textH) / 2.0f;

    DrawText(text, x, y, scale, tint);
}

// ---------------------------------------------------------------------------
// BitmapFont::DrawTextRotated
// ---------------------------------------------------------------------------
void BitmapFont::DrawTextRotated(const char* text, Vector2 center, float angleDeg, float scale, Color tint) const {
    if (!text || m_atlas.id == 0) return;

    int textW = MeasureText(text, scale);
    float textH = (float)m_glyphHeight * scale;
    float halfW = (float)textW / 2.0f;
    float halfH = textH / 2.0f;

    float renderAngle = -angleDeg;
    float rad = renderAngle * (PI / 180.0f);
    float cosA = std::cos(rad);
    float sinA = std::sin(rad);

    float cursorX = 0.0f;
    size_t len = std::strlen(text);

    for (size_t i = 0; i < len; ++i) {
        char ch = text[i];
        auto it = m_glyphs.find(ch);
        if (it == m_glyphs.end()) continue;

        const GlyphInfo& glyph = it->second;

        if (glyph.srcRect.width > 0 && glyph.srcRect.height > 0) {
            float localX = cursorX + glyph.offset.x * scale - halfW;
            float localY = glyph.offset.y * scale - halfH;

            float rotX = center.x + localX * cosA - localY * sinA;
            float rotY = center.y + localX * sinA + localY * cosA;

            Rectangle dest = {
                rotX,
                rotY,
                glyph.srcRect.width * scale,
                glyph.srcRect.height * scale
            };
            DrawTexturePro(m_atlas, glyph.srcRect, dest, Vector2{ 0.0f, 0.0f }, renderAngle, tint);
        }

        cursorX += (float)glyph.advanceWidth * scale;

        if (i + 1 < len) {
            uint16_t key = ((uint16_t)(uint8_t)ch << 8) | (uint16_t)(uint8_t)text[i + 1];
            auto kit = m_kerning.find(key);
            if (kit != m_kerning.end()) {
                cursorX += (float)kit->second * scale;
            }
        }
    }
}

