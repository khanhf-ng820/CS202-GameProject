#pragma once
#include "raylib.h"
#include "reanim.h"
#include <string>
#include <vector>
#include <unordered_map>

class Resources {
public:
    static Resources& GetInstance();

    void LoadAll(const std::string& filePath);
    void LoadMinimalForLoadingScreen();
    void PrepareAssetLoadingQueue(const std::vector<std::string>& dirPaths);
    bool StepAssetLoadingQueue(int batchSize = 3);
    int GetTotalAssetCount() const { return m_totalAssetCount; }
    int GetLoadedAssetCount() const { return m_loadedAssetCount; }
    float GetLoadingProgress() const;
    void LoadFile(const std::string& path);
    void UnloadAll();

    std::string GetAssetPath(const std::string& relativePath);
    Texture2D GetBackground() const { return background; }
    Texture2D GetTexture(const std::string& name) const;
    bool IsPixelTransparent(const std::string& name, int x, int y) const;
    std::string FormatAnimName(const std::string& raw) const;
    ReanimDefinition LoadReanim(const std::string& filePath);

private:
    std::unordered_map<std::string, Texture2D> textures;
    std::unordered_map<std::string, Image> images;
    std::unordered_map<std::string, ReanimDefinition> reanims;
    Texture2D background;

    std::vector<std::string> m_pendingFileQueue;
    int m_totalAssetCount = 0;
    int m_loadedAssetCount = 0;

    Resources() = default;
    ~Resources() = default;
    Resources(const Resources&) = delete;
    Resources& operator=(const Resources&) = delete;
};

