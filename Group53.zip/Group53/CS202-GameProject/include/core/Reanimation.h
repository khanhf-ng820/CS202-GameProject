#pragma once
#include "raylib.h"
#include "reanim.h"
#include "resources.h"
#include <vector>
#include <string>
#include <unordered_map>

class Reanimation {
public:
    Reanimation() = default;
    Reanimation(const ReanimDefinition& def, const Resources& resources);
    void SetResources(const ReanimDefinition& def, const Resources& resources);
    void Update(float dt);
    void Draw(float x, float y, float scale) const;
    void Draw(float x, float y, float scale, Color tint) const;
    void Draw(Vector2 position, float scale) const;
    void Draw(Vector2 position, float scale, Color tint) const;

    // Playback control
    void SetAnimation(const std::string& animName);
    void SetAnimationIndex(int index);
    void SetBaseAnimation(const std::string& animName);
    void SetBaseAnimationIndex(int index);
    void SetSpeed(float speed);
    float GetSpeed() const;
    void SetPaused(bool paused);
    bool IsPaused() const;
    void TogglePause();
    void SetFrame(float frame);
    void SetLooping(bool looping);
    bool IsLooping() const;
    bool IsFinished() const;

    // Query methods
    int GetCurrentFrame() const;
    int GetEndFrame() const;
    std::string GetCurrentAnimName() const;
    std::string GetFormattedAnimName() const;
    const std::vector<AnimationRange>& GetAnimations() const;
    int GetCurrentAnimIndex() const;
    void SetTrackVisible(const std::string& trackName, bool visible);
    void OverrideTrackImage(const std::string& trackName, const std::string& imageName);
    void ClearTrackImageOverride(const std::string& trackName);
    void AddCustomAnimation(const std::string& newAnimName, const std::string& baseAnimName);
    void BakeChildRotation(const std::string& parentTrack, const std::string& childTrack, const std::string& animName);
    void AddCustomAnimation(const std::string& newAnimName, int startFrame, int endFrame);
    float GetLoopStartTime(int animIndex) const;

    // Get the bounding rectangle of a named track at the current frame,
    // given the draw position and scale. Returns {0,0,0,0} if track not found/hidden.
    Rectangle GetTrackBounds(const std::string& trackName, float x, float y, float scale) const;
    bool GetTrackTransform(const std::string& trackName, float& outX, float& outY, float& outRotDeg) const;

private:
    void PopulateAnimations();
    ReanimKeyframe GetInterpolatedKeyframe(const ReanimTrack& track, float frameFloat, int animIndex) const;

    ReanimDefinition m_def;
    const Resources* m_resources = nullptr;

    float m_currentFrameFloat = 0.0f;
    int m_currentAnimIndex = 0;
    float m_baseFrameFloat = 0.0f;
    int m_baseAnimIndex = -1;
    std::vector<AnimationRange> m_anims;
    float m_speedMultiplier = 1.0f;
    bool m_isPaused = false;
    bool m_isLooping = true;
    std::unordered_map<std::string, bool> m_trackVisibility;
    std::unordered_map<std::string, std::string> m_trackImageOverrides;
};
